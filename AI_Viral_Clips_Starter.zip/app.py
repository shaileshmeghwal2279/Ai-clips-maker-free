import os, uuid, threading, subprocess, json, re, shutil
from pathlib import Path
from flask import Flask, render_template, request, jsonify, send_from_directory, abort
from werkzeug.utils import secure_filename

BASE = Path(__file__).parent
WORK = BASE / "work"
WORK.mkdir(exist_ok=True)
JOBS = {}
LOCK = threading.Lock()
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024 * 1024

def run(cmd):
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if p.returncode:
        raise RuntimeError((p.stderr or p.stdout)[-2500:])
    return p.stdout

def safe_name(s):
    return re.sub(r"[^a-zA-Z0-9_-]", "", s)[:40] or "clip"

def process_job(job_id, url, count, duration, ratio, captions):
    folder = WORK / job_id
    folder.mkdir(parents=True, exist_ok=True)
    def update(**kw):
        with LOCK:
            JOBS[job_id].update(kw)
    try:
        update(status="downloading", progress=8, message="Fetching your permitted video…")
        # Use only videos you own or have permission to download/edit.
        run(["yt-dlp", "--no-playlist", "-f", "bv*+ba/b", "--merge-output-format", "mp4",
             "--max-filesize", "2G", "-o", str(folder / "source.%(ext)s"), url])
        source = next((p for p in folder.glob("source.*") if p.suffix.lower() in [".mp4",".mkv",".webm",".mov"]), None)
        if not source:
            raise RuntimeError("Could not find a downloaded video file.")
        info = json.loads(run(["ffprobe", "-v", "quiet", "-print_format", "json", "-show_format", "-show_streams", str(source)]))
        total = float(info["format"]["duration"])
        update(status="analyzing", progress=25, message="Finding engaging moments with speech analysis…")

        segments = []
        try:
            from faster_whisper import WhisperModel
            model = WhisperModel(os.getenv("WHISPER_MODEL", "base"), device="cpu", compute_type="int8")
            transcript, _ = model.transcribe(str(source), vad_filter=True, word_timestamps=False)
            for seg in transcript:
                text = (seg.text or "").strip()
                if text:
                    segments.append({"start": float(seg.start), "end": float(seg.end), "text": text})
        except Exception as e:
            # A fallback keeps the workflow usable even if speech recognition is unavailable.
            segments = []

        picks = []
        if segments:
            keywords = ["wow","what","why","how","secret","amazing","best","never","love","hate",
                        "देखो","क्या","अरे","वाह","कमाल","मजेदार","सच","क्यों","कैसे"]
            scored = []
            for s in segments:
                t = s["text"].lower()
                score = sum(2 for k in keywords if k in t) + min(len(t)/90, 2)
                score += 0.5 if "!" in t or "?" in t else 0
                scored.append((score, s))
            scored.sort(key=lambda x: x[0], reverse=True)
            for score, seg in scored:
                center = (seg["start"] + seg["end"]) / 2
                start = max(0, center - duration/2)
                end = min(total, start + duration)
                start = max(0, end - duration)
                if all(abs(start - p["start"]) > duration * .7 for p in picks):
                    picks.append({"start": start, "end": end, "score": score, "transcript": seg["text"]})
                if len(picks) >= count: break
        if not picks:
            # No transcript available: evenly spaced preview moments, clearly labeled as fallback.
            step = max(duration, total / (count + 1))
            for i in range(count):
                start = min(max(0, (i+1)*step - duration/2), max(0,total-duration))
                picks.append({"start": start, "end": min(total,start+duration), "score": 0, "transcript": ""})
        picks.sort(key=lambda x: x["start"])
        update(status="rendering", progress=55, message="Creating vertical clips and subtitles…")
        output = []
        for i, pick in enumerate(picks, 1):
            start, end = pick["start"], pick["end"]
            clip = f"clip_{i:02d}.mp4"
            srt = folder / f"clip_{i:02d}.srt"
            if captions and segments:
                with open(srt, "w", encoding="utf-8") as f:
                    n = 1
                    for seg in segments:
                        a, b = max(seg["start"],start), min(seg["end"],end)
                        if b > a:
                            def ts(v):
                                ms = int((v-int(v))*1000); sec=int(v)%60; mins=int(v//60)%60; hrs=int(v//3600)
                                return f"{hrs:02}:{mins:02}:{sec:02},{ms:03}"
                            f.write(f"{n}\n{ts(a-start)} --> {ts(b-start)}\n{seg['text']}\n\n"); n += 1
            vf = "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920"
            if captions and segments and srt.exists():
                # Escape path for ffmpeg subtitles filter.
                sp = str(srt).replace("\\", "/").replace(":", r"\\:")
                vf += f",subtitles='{sp}':force_style='FontSize=18,Outline=2,Alignment=2,MarginV=130'"
            run(["ffmpeg","-y","-ss",str(start),"-i",str(source),"-t",str(end-start),
                 "-vf",vf,"-c:v","libx264","-preset","veryfast","-crf","23",
                 "-c:a","aac","-b:a","128k","-movflags","+faststart",str(folder/clip)])
            output.append({"name":clip,"url":f"/clips/{job_id}/{clip}",
                           "start":round(start,1),"end":round(end,1),
                           "transcript":pick["transcript"]})
            update(progress=55 + int(40*i/len(picks)), clips=output)
        update(status="done", progress=100, message="Your clips are ready!", clips=output)
    except Exception as e:
        update(status="error", progress=0, message=str(e)[:1000])

@app.route("/")
def index():
    return render_template("index.html")

@app.post("/api/jobs")
def create_job():
    data = request.get_json(force=True)
    url = (data.get("url") or "").strip()
    if not re.match(r"^https?://", url):
        return jsonify(error="Please enter a valid video URL."), 400
    count = max(1,min(10,int(data.get("count",5))))
    duration = max(15,min(90,int(data.get("duration",40))))
    ratio = data.get("ratio","9:16")
    captions = bool(data.get("captions",True))
    job_id = uuid.uuid4().hex[:12]
    with LOCK:
        JOBS[job_id] = {"status":"queued","progress":0,"message":"Job queued","clips":[]}
    threading.Thread(target=process_job,args=(job_id,url,count,duration,ratio,captions),daemon=True).start()
    return jsonify(job_id=job_id)

@app.get("/api/jobs/<job_id>")
def job_status(job_id):
    with LOCK:
        job = JOBS.get(job_id)
        if not job: return jsonify(error="Job not found. Restart the server and try again."),404
        return jsonify(job)

@app.get("/clips/<job_id>/<filename>")
def download_clip(job_id, filename):
    if not re.fullmatch(r"[a-f0-9]{12}", job_id) or not re.fullmatch(r"clip_[0-9]{2}\.mp4", filename):
        abort(404)
    return send_from_directory(WORK/job_id, filename, as_attachment=True, download_name=filename)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT",5000)), debug=False)
