const $=id=>document.getElementById(id);
let timer=null;
function show(id){$(id).classList.remove("hidden")}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
$("start").addEventListener("click",async()=>{
 const url=$("url").value.trim(); if(!url){alert("Paste a video URL first.");return}
 $("start").disabled=true; $("start").textContent="Starting…"; show("progress"); $("results").classList.add("hidden");
 try{
  const r=await fetch("/api/jobs",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({url,count:$("count").value,duration:$("duration").value,captions:$("captions").checked})});
  const d=await r.json(); if(!r.ok)throw new Error(d.error||"Could not start job");
  poll(d.job_id);
 }catch(e){$("message").textContent=e.message;$("start").disabled=false;$("start").textContent="✦ Generate best clips"}
});
async function poll(id){
 try{
  const r=await fetch("/api/jobs/"+id);const d=await r.json();
  $("status").textContent=d.status==="done"?"Completed":d.status==="error"?"Something went wrong":d.status[0].toUpperCase()+d.status.slice(1);
  $("percent").textContent=(d.progress||0)+"%";$("bar").style.width=(d.progress||0)+"%";$("message").textContent=d.message||"";
  if(d.clips&&d.clips.length){show("results");$("clips").innerHTML=d.clips.map((c,i)=>`<article class="clip"><strong>Clip ${String(i+1).padStart(2,"0")}</strong><small>${c.start}s – ${c.end}s</small>${c.transcript?`<p>${esc(c.transcript)}</p>`:""}<a href="${c.url}">↓ Download MP4</a></article>`).join("")}
  if(d.status==="done"||d.status==="error"){$("start").disabled=false;$("start").textContent="✦ Generate more clips";return}
  timer=setTimeout(()=>poll(id),2500);
 }catch(e){$("message").textContent=e.message;$("start").disabled=false}
}
