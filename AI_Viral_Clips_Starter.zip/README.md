# AI Viral Clips — starter website

A responsive public-web-app starter that accepts a video URL, downloads/processes it on the server, transcribes speech with Faster-Whisper, ranks candidate moments with a lightweight heuristic, creates 9:16 MP4 clips with optional burned-in captions, and exposes download links.

## Important legal and operational notes
- Use only videos you own or have explicit permission to download, edit, and redistribute. Respect YouTube's Terms of Service, copyright, and the rights of people appearing in videos.
- This is a starter/MVP, not a production SaaS. Add authentication, per-user quotas, rate limiting, job persistence, storage expiry, abuse prevention, monitoring, and a queue before opening it to the public.
- "Free" hosting is not guaranteed for video processing. CPU, memory, disk, bandwidth, and speech-to-text costs can exceed free-tier limits. Long videos can exhaust a small server.
- The current app keeps job state in memory and stores outputs under `work/`; restarting the server clears job state. Use object storage and a database for production.
- The moment-ranking heuristic is basic. It prioritizes expressive/key phrases and longer speech segments; it is not a trained virality predictor.
- The UI offers auto captions, but if speech recognition fails it will still create evenly spaced clips without captions.

## Run locally
Requires Python 3.11+, FFmpeg, and (for URL extraction) yt-dlp-supported sources.

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\\Scripts\\activate
pip install -r requirements-prod.txt
python app.py
```
Open http://localhost:5000

## Deploy
Build with Docker on a host that supports background CPU-intensive jobs and FFmpeg. Set the service start command to `gunicorn -w 1 --threads 4 -b 0.0.0.0:$PORT app:app --timeout 3600`. A small free web dyno is unlikely to reliably process long videos. For a public launch, split the web app and worker, add persistent object storage, queueing, quotas, and user accounts.
